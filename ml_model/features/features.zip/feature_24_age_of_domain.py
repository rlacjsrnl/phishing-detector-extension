import whois
from urllib.parse import urlparse
from datetime import datetime
import time
import socket
from dateutil import parser

# WHOIS 요청 timeout 제한 (5초)
socket.setdefaulttimeout(5)


def safe_whois(domain, retries=3, delay=2):
    for i in range(retries):
        try:
            return whois.whois(domain)
        except Exception as e:
            print(f"[WHOIS 재시도 {i+1} - {domain}] 실패 → {e}")
            time.sleep(delay)
    return None


def feature_24_age_of_domain(url: str) -> int:
    """
    WHOIS 정보 기반 도메인 생성일로부터의 나이 계산

    Returns:
        -1 : 6개월 이상 된 도메인 (정상)
         1 : 6개월 미만 또는 정보 없음 (피싱 가능성)
    """
    try:
        domain = urlparse(url).netloc.split(":")[0]
        w = safe_whois(domain)

        if w is None:
            return 1  # WHOIS 요청 실패 시 피싱 의심

        creation_date = w.creation_date

        if isinstance(creation_date, list):
            creation_date = creation_date[0]
        if isinstance(creation_date, str):
            creation_date = parser.parse(creation_date)

        if not creation_date:
            return 1  # 정보 없음

        now = datetime.now()
        age_days = (now - creation_date).days

        return -1 if age_days >= 180 else 1
    except Exception as e:
        print(f"[WHOIS 예외 - {url}] {e}")
        return 1  # 예외 발생 시 피싱 간주


# 테스트
if __name__ == "__main__":
    test_urls = [
        "https://google.com",             # 오래된 도메인 → -1
        "https://a-newly-made.xyz",       # 신규 도메인 가능성 → 1
    ]
    for url in test_urls:
        print(f"{url} → {feature_24_age_of_domain(url)}")
